import React, {useEffect, useMemo, useRef, useState} from "react";
import "./App.scss"
//import {BrowserRouter, Route, Routes} from "react-router-dom";

import {
    BrowserRouter,
    Routes,
    Route,
    Link, Navigate,

} from "react-router-dom";

import About from "./pages/About";
import Posts from "./pages/Posts";
import Navbar from "./Components/UI/Nuvbar/Navbar";
import Page404 from "./pages/Page404";
import Homepage from "./pages/Homepage";
import AppRouter from "./Components/AppRouter";

function App() {
   return(
       <BrowserRouter>
           <Navbar/>
            <AppRouter/>
       </BrowserRouter>

   )

}

export default App;

