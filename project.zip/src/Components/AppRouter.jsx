import React from 'react';
import {Route, Routes} from "react-router-dom";
import {routes} from "./router/index";
import Homepage from "../pages/Homepage";
import Page404 from "../pages/Page404";
import About from "../pages/About";
import Posts from "../pages/Posts";
import PostIdPage from "../pages/PostIdPage";


const AppRouter = () => {

   console.log(routes[2].exact + ' ' + routes[2].path+ ' ' + routes[2].element())

    return (
        <Routes>
            <Route index element={<Homepage/>} />


            <Route path="/about" element={<About/>} />
            <Route exact path ="/posts" element={ <Posts/> } />
            {/*<Route exact path ={routes[1].path} element={ routes[1].element()}  />*/}
            {/*<Route exact path ="/posts/:id" element={ <PostIdPage/> } />*/}
            {/*<Route exact path ={routes[2].path} element={ routes[2].element } />*/}
            <Route exact path ={routes[2].path} element={ routes[2].element } />


            {/*{routes.map(route=>*/}
            {/*    // <Route component={route.component} path={route.path} exact={route.exact}/>*/}
            {/*        <Route key={route.id} exact path={route.path} element={ route.element() }/>*/}
            {/*    )}*/}

            <Route path ="*" element={ <Page404/> } />
        </Routes>
    );
};

export default AppRouter;