import About from "../../pages/About";
import Posts from "../../pages/Posts";
import PostIdPage from "../../pages/PostIdPage";
import Homepage from "../../pages/Homepage";
import Page404 from "../../pages/Page404";


export const routes =[
    // {id: 1, path: '/', component: Homepage, exact: "exact"},
    {id: 2, path: '/about', element: About, exact: ""},
    {id: 3, path: '/posts', element: Posts, exact: true},
    {id: 4, path: "/posts/:id", element: PostIdPage, exact: true},
    // {id: 5, path: '*', component: Page404, exact: "exact"},

]

// export const ing= ()=>{ console.log(routes[1].component); console.log('ggggggggggg') }