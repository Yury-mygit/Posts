import React from 'react';

const Homepage = () => {
    return (
        <h1>
            HOME PAGE
        </h1>
    );
};

export default Homepage;