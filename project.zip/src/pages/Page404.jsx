import React from 'react';

const Page404 = () => {
    return (
        <h1>
            Not found. 404
        </h1>
    );
};

export default Page404;